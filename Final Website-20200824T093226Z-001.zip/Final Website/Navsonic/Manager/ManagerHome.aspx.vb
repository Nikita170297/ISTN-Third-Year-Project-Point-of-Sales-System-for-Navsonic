﻿
Partial Class Manager_ManagerHome
    Inherits System.Web.UI.Page

End Class
