﻿
Partial Class Manager_ManagerHelp
    Inherits System.Web.UI.Page

End Class
