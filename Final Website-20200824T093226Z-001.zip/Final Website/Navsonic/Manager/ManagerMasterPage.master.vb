﻿
Partial Class Manager_ManagerMasterPage
    Inherits System.Web.UI.MasterPage
End Class

