﻿
Partial Class Manager_Edit_Catalogue
    Inherits System.Web.UI.Page

End Class
