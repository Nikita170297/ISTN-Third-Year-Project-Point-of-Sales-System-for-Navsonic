﻿
Partial Class Public_Pages_ContactPage
    Inherits System.Web.UI.Page

End Class
