﻿
Partial Class Private_Pages_CustomerMasterPage
    Inherits System.Web.UI.MasterPage
End Class

