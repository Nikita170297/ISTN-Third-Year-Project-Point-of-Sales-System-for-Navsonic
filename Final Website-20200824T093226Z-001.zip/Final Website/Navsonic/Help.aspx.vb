﻿
Partial Class Help
    Inherits System.Web.UI.Page

End Class
