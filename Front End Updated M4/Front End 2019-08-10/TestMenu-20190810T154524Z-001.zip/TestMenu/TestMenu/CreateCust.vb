﻿Public Class CreateCust
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtName.Clear()
        txtEmail.Clear()
        txtLName.Clear()
        txtNumber.Clear()
        txtAddress.Clear()
        cmbStatus.Text = ""

        

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles txtCustRewards.TextChanged

    End Sub

    Private Sub CreateCust_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtCustRewards.Text = "R0.00"
        cmbStatus.Text = "Active"

    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click

        Me.Close()

    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click

        Try
            If (txtName.Text <> "" And txtLName.Text <> "" And txtEmail.Text <> "" And txtNumber.Text <> "" And txtEmail.Text <> "") Then
                Dim custrewards As Decimal = 0.0
                Customer_DetailsTableAdapter1.Insert(txtName.Text, txtLName.Text, txtAddress.Text, txtNumber.Text, custrewards, txtEmail.Text, cmbStatus.Text)
                MsgBox("Customer Added!")
            Else
                MessageBox.Show("Please Fill in all details")
            End If

        Catch ex As Exception
            MessageBox.Show("Please ensure all details are correct")
        Finally
            txtName.Clear()
            txtEmail.Clear()
            txtLName.Clear()
            txtNumber.Clear()
            txtAddress.Clear()
            cmbStatus.Text = ""

        End Try
    End Sub

    Private Sub txtName_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtName.KeyPress
        If (e.KeyChar < "0" OrElse e.KeyChar > "9") Then
            e.Handled = False



        Else
            e.Handled = True

        End If
    End Sub

    Private Sub txtLName_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtLName.KeyPress
        If (e.KeyChar < "0" OrElse e.KeyChar > "9") Then
            e.Handled = False



        Else
            e.Handled = True

        End If
    End Sub

    Private Sub txtNumber_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtNumber.KeyPress
        If (e.KeyChar < "0" OrElse e.KeyChar > "9") AndAlso (e.KeyChar <> ControlChars.Back AndAlso e.KeyChar <> ",") Then
            e.Handled = True



        End If
    End Sub
End Class