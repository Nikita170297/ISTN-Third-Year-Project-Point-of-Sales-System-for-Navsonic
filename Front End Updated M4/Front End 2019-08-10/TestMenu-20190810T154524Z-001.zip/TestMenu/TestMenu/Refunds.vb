﻿Public Class Refunds
    Dim sum As Decimal
    Dim price As Decimal
    Dim lineid As Integer
    Dim prPrice As Decimal
    Dim quantity2 As Integer
    Private Sub txtSaleID_TextChanged(sender As Object, e As EventArgs) Handles txtSaleID.TextChanged
        If txtSaleID.Text = "" Then
            Sale_LineTableAdapter1.Fill(Group7DataSet1.Sale_Line)
            ' Sale_LineTableAdapter1.FillBy(Group7DataSet1.Sale_Line, 0)
        Else
            Sale_LineTableAdapter1.FillBy(Group7DataSet1.Sale_Line, txtSaleID.Text)

        End If


    End Sub

    Private Sub Refunds_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Group7DataSet2.Products' table. You can move, or remove it, as needed.
        Me.ProductsTableAdapter.Fill(Me.Group7DataSet2.Products)
        Sale_LineTableAdapter1.Fill(Group7DataSet1.Sale_Line)
        'Sale_LineTableAdapter2.FillBy1(Group7DataSet2.Sale_Line, quantity2, prPrice, txtSaleID.Text, lineid)
        Product_SaleTableAdapter1.Fill(Group7DataSet1.Product_Sale)

    End Sub

    Private Sub DataGridView2_RowHeaderMouseDoubleClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles Saleline1Grid.RowHeaderMouseDoubleClick
        Dim quanity As String


        ' Dim SaleId As Integer
        Dim row As DataRow
        row = Group7DataSet1.Sale_Line.NewRow

        For i As Integer = 0 To row.ItemArray.Count - 1
            row.Item(i) = Saleline1Grid.CurrentRow.Cells(i).Value

        Next
        Dim pq As Integer = row.Item(3)
        Dim qProd As Integer
        Dim prodID As Integer
        Dim prodQuantity As Integer = 0
        quanity = InputBox("Enter Quantity To Refund")
        quantity2 = CInt(quanity)
        While (quantity2 > pq)
            MessageBox.Show("Wrong quantity")
            quanity = InputBox("Enter Quantity To Refund")
            quantity2 = CInt(quanity)
        End While


        For i = 0 To Group7DataSet2.Products.Rows.Count - 1

            If Group7DataSet2.Products.Rows(i).Item(0) = row.Item(1) Then
                prodID = Group7DataSet2.Products.Rows(i).Item(0)
                prPrice = Group7DataSet2.Products.Rows(i).Item(2) * quantity2
                qProd = Group7DataSet2.Products.Rows(i).Item(3)

            End If
        Next


        price = prPrice * quantity2
        sum = price
        lineid = row.Item(0)
        Dim newQuantity As Decimal
        newQuantity = qProd + quantity2
        ProductsTableAdapter.UpdateQuantity(newQuantity, prodID, prodID)
        Refund_LineTableAdapter1.Insert(lineid, prodID, txtSaleID.Text, quantity2, prPrice)
        Refund_LineTableAdapter1.FillBy(Group7DataSet1.Refund_Line, txtSaleID.Text)


        txtTotRefund.Text = sum
    End Sub

    Private Sub btnRefundProducts_Click(sender As Object, e As EventArgs) Handles btnRefundProducts.Click
        Dim txtcustID As Integer
        For i = 0 To Group7DataSet1.Product_Sale.Rows.Count - 1
            If Group7DataSet1.Product_Sale.Rows(i).Item(0) = txtSaleID.Text Then
                txtcustID = Group7DataSet1.Product_Sale.Rows(i).Item(2)
            End If
        Next
        Product_RefundTableAdapter1.Insert(txtSaleID.Text, txtcustID)
        MsgBox("Amount Refunded R" & txtTotRefund.Text)
        MsgBox("Product Refunded!")

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Me.Close()

    End Sub

    Private Sub txtSaleID_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtSaleID.KeyPress
        If (e.KeyChar < "0" OrElse e.KeyChar > "9") AndAlso (e.KeyChar <> ControlChars.Back AndAlso e.KeyChar <> ",") Then
            e.Handled = True



        End If
    End Sub
End Class