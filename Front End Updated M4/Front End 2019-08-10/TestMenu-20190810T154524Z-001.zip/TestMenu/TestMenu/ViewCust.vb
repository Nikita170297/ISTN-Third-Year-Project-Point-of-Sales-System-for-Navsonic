﻿Public Class ViewCust
    Private Sub btnBack_Click(sender As Object, e As EventArgs)
        Form1.Show()
        Me.Close()

    End Sub

    Private Sub txtSearch_TextChanged(sender As Object, e As EventArgs) Handles txtSearch.TextChanged
        Customer_DetailsTableAdapter1.Fillby2(DSCustomer.Customer_Details, txtSearch.Text)
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        CustomerDetailsBindingSource.MoveFirst()


    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        CustomerDetailsBindingSource.MoveNext()

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        CustomerDetailsBindingSource.MovePrevious()
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        CustomerDetailsBindingSource.MoveLast()

    End Sub

    Private Sub btnBack_Click_1(sender As Object, e As EventArgs) Handles btnBack.Click

        Me.Close()

    End Sub

    Private Sub ViewCust_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Customer_DetailsTableAdapter1.Fill(DSCustomer.Customer_Details)
        Me.WindowState = FormWindowState.Maximized
    End Sub
End Class