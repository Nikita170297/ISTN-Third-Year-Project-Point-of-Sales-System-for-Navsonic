﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Refunds
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Refunds))
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtSaleID = New System.Windows.Forms.TextBox()
        Me.SaleLineBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Group7DataSet2 = New TestMenu.group7DataSet()
        Me.Saleline1Grid = New System.Windows.Forms.DataGridView()
        Me.LineItemIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ProductIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SaleIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.UnitQuantityDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SalePriceDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.Group7DataSet1 = New TestMenu.group7DataSet()
        Me.btnRefundProducts = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtTotRefund = New System.Windows.Forms.TextBox()
        Me.Sale = New System.Windows.Forms.GroupBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.LineItemIDDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ProductIDDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SaleIDDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.UnitQuantityDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SalePriceDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BindingSource3 = New System.Windows.Forms.BindingSource(Me.components)
        Me.Sale_LineTableAdapter1 = New TestMenu.group7DataSetTableAdapters.Sale_LineTableAdapter()
        Me.Sale_LineTableAdapter2 = New TestMenu.group7DataSetTableAdapters.Sale_LineTableAdapter()
        Me.BindingSource2 = New System.Windows.Forms.BindingSource(Me.components)
        Me.ProductsTableAdapter = New TestMenu.group7DataSetTableAdapters.ProductsTableAdapter()
        Me.Sale_Line1TableAdapter1 = New TestMenu.group7DataSetTableAdapters.Sale_Line1TableAdapter()
        Me.Product_SaleTableAdapter1 = New TestMenu.group7DataSetTableAdapters.Product_SaleTableAdapter()
        Me.Product_RefundTableAdapter1 = New TestMenu.group7DataSetTableAdapters.Product_RefundTableAdapter()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Refund_LineTableAdapter1 = New TestMenu.group7DataSetTableAdapters.Refund_LineTableAdapter()
        CType(Me.SaleLineBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Group7DataSet2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Saleline1Grid, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Group7DataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Sale.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BindingSource3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BindingSource2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(13, 47)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(70, 25)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Sale ID"
        '
        'txtSaleID
        '
        Me.txtSaleID.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSaleID.Location = New System.Drawing.Point(103, 47)
        Me.txtSaleID.Margin = New System.Windows.Forms.Padding(2)
        Me.txtSaleID.Name = "txtSaleID"
        Me.txtSaleID.Size = New System.Drawing.Size(142, 34)
        Me.txtSaleID.TabIndex = 11
        '
        'SaleLineBindingSource
        '
        Me.SaleLineBindingSource.DataMember = "Sale_Line"
        Me.SaleLineBindingSource.DataSource = Me.Group7DataSet2
        '
        'Group7DataSet2
        '
        Me.Group7DataSet2.DataSetName = "group7DataSet"
        Me.Group7DataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Saleline1Grid
        '
        Me.Saleline1Grid.AutoGenerateColumns = False
        Me.Saleline1Grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Saleline1Grid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.LineItemIDDataGridViewTextBoxColumn, Me.ProductIDDataGridViewTextBoxColumn, Me.SaleIDDataGridViewTextBoxColumn, Me.UnitQuantityDataGridViewTextBoxColumn, Me.SalePriceDataGridViewTextBoxColumn})
        Me.Saleline1Grid.DataSource = Me.BindingSource1
        Me.Saleline1Grid.Location = New System.Drawing.Point(9, 30)
        Me.Saleline1Grid.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Saleline1Grid.Name = "Saleline1Grid"
        Me.Saleline1Grid.Size = New System.Drawing.Size(569, 220)
        Me.Saleline1Grid.TabIndex = 82
        '
        'LineItemIDDataGridViewTextBoxColumn
        '
        Me.LineItemIDDataGridViewTextBoxColumn.DataPropertyName = "Line_ItemID"
        Me.LineItemIDDataGridViewTextBoxColumn.HeaderText = "Line_ItemID"
        Me.LineItemIDDataGridViewTextBoxColumn.Name = "LineItemIDDataGridViewTextBoxColumn"
        Me.LineItemIDDataGridViewTextBoxColumn.ReadOnly = True
        '
        'ProductIDDataGridViewTextBoxColumn
        '
        Me.ProductIDDataGridViewTextBoxColumn.DataPropertyName = "Product_ID"
        Me.ProductIDDataGridViewTextBoxColumn.HeaderText = "Product_ID"
        Me.ProductIDDataGridViewTextBoxColumn.Name = "ProductIDDataGridViewTextBoxColumn"
        '
        'SaleIDDataGridViewTextBoxColumn
        '
        Me.SaleIDDataGridViewTextBoxColumn.DataPropertyName = "Sale_ID"
        Me.SaleIDDataGridViewTextBoxColumn.HeaderText = "Sale_ID"
        Me.SaleIDDataGridViewTextBoxColumn.Name = "SaleIDDataGridViewTextBoxColumn"
        '
        'UnitQuantityDataGridViewTextBoxColumn
        '
        Me.UnitQuantityDataGridViewTextBoxColumn.DataPropertyName = "Unit_Quantity"
        Me.UnitQuantityDataGridViewTextBoxColumn.HeaderText = "Unit_Quantity"
        Me.UnitQuantityDataGridViewTextBoxColumn.Name = "UnitQuantityDataGridViewTextBoxColumn"
        '
        'SalePriceDataGridViewTextBoxColumn
        '
        Me.SalePriceDataGridViewTextBoxColumn.DataPropertyName = "Sale_Price"
        Me.SalePriceDataGridViewTextBoxColumn.HeaderText = "Sale_Price"
        Me.SalePriceDataGridViewTextBoxColumn.Name = "SalePriceDataGridViewTextBoxColumn"
        '
        'BindingSource1
        '
        Me.BindingSource1.DataMember = "Sale_Line"
        Me.BindingSource1.DataSource = Me.Group7DataSet1
        '
        'Group7DataSet1
        '
        Me.Group7DataSet1.DataSetName = "group7DataSet"
        Me.Group7DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'btnRefundProducts
        '
        Me.btnRefundProducts.BackColor = System.Drawing.Color.Transparent
        Me.btnRefundProducts.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnRefundProducts.Font = New System.Drawing.Font("Segoe UI", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRefundProducts.Location = New System.Drawing.Point(447, 605)
        Me.btnRefundProducts.Margin = New System.Windows.Forms.Padding(2)
        Me.btnRefundProducts.Name = "btnRefundProducts"
        Me.btnRefundProducts.Size = New System.Drawing.Size(157, 46)
        Me.btnRefundProducts.TabIndex = 83
        Me.btnRefundProducts.Text = "Refund Product/s"
        Me.btnRefundProducts.UseVisualStyleBackColor = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Segoe UI", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(13, 626)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(137, 25)
        Me.Label3.TabIndex = 84
        Me.Label3.Text = "Total Refunded"
        '
        'txtTotRefund
        '
        Me.txtTotRefund.Enabled = False
        Me.txtTotRefund.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotRefund.Location = New System.Drawing.Point(161, 626)
        Me.txtTotRefund.Margin = New System.Windows.Forms.Padding(2)
        Me.txtTotRefund.Name = "txtTotRefund"
        Me.txtTotRefund.Size = New System.Drawing.Size(142, 34)
        Me.txtTotRefund.TabIndex = 85
        '
        'Sale
        '
        Me.Sale.BackColor = System.Drawing.Color.Transparent
        Me.Sale.Controls.Add(Me.Saleline1Grid)
        Me.Sale.Font = New System.Drawing.Font("Segoe UI", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Sale.Location = New System.Drawing.Point(11, 114)
        Me.Sale.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Sale.Name = "Sale"
        Me.Sale.Padding = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.Sale.Size = New System.Drawing.Size(586, 270)
        Me.Sale.TabIndex = 86
        Me.Sale.TabStop = False
        Me.Sale.Text = "Sale Items"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.DataGridView1)
        Me.GroupBox1.Font = New System.Drawing.Font("Segoe UI", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(11, 390)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.GroupBox1.Size = New System.Drawing.Size(594, 201)
        Me.GroupBox1.TabIndex = 87
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Items Being Refunded"
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.LineItemIDDataGridViewTextBoxColumn1, Me.ProductIDDataGridViewTextBoxColumn1, Me.SaleIDDataGridViewTextBoxColumn1, Me.UnitQuantityDataGridViewTextBoxColumn1, Me.SalePriceDataGridViewTextBoxColumn1})
        Me.DataGridView1.DataSource = Me.BindingSource3
        Me.DataGridView1.Location = New System.Drawing.Point(7, 29)
        Me.DataGridView1.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.Size = New System.Drawing.Size(571, 163)
        Me.DataGridView1.TabIndex = 0
        '
        'LineItemIDDataGridViewTextBoxColumn1
        '
        Me.LineItemIDDataGridViewTextBoxColumn1.DataPropertyName = "Line_ItemID"
        Me.LineItemIDDataGridViewTextBoxColumn1.HeaderText = "Line_ItemID"
        Me.LineItemIDDataGridViewTextBoxColumn1.Name = "LineItemIDDataGridViewTextBoxColumn1"
        Me.LineItemIDDataGridViewTextBoxColumn1.ReadOnly = True
        '
        'ProductIDDataGridViewTextBoxColumn1
        '
        Me.ProductIDDataGridViewTextBoxColumn1.DataPropertyName = "Product_ID"
        Me.ProductIDDataGridViewTextBoxColumn1.HeaderText = "Product_ID"
        Me.ProductIDDataGridViewTextBoxColumn1.Name = "ProductIDDataGridViewTextBoxColumn1"
        '
        'SaleIDDataGridViewTextBoxColumn1
        '
        Me.SaleIDDataGridViewTextBoxColumn1.DataPropertyName = "Sale_ID"
        Me.SaleIDDataGridViewTextBoxColumn1.HeaderText = "Sale_ID"
        Me.SaleIDDataGridViewTextBoxColumn1.Name = "SaleIDDataGridViewTextBoxColumn1"
        '
        'UnitQuantityDataGridViewTextBoxColumn1
        '
        Me.UnitQuantityDataGridViewTextBoxColumn1.DataPropertyName = "Unit_Quantity"
        Me.UnitQuantityDataGridViewTextBoxColumn1.HeaderText = "Unit_Quantity"
        Me.UnitQuantityDataGridViewTextBoxColumn1.Name = "UnitQuantityDataGridViewTextBoxColumn1"
        '
        'SalePriceDataGridViewTextBoxColumn1
        '
        Me.SalePriceDataGridViewTextBoxColumn1.DataPropertyName = "Sale_Price"
        Me.SalePriceDataGridViewTextBoxColumn1.HeaderText = "Sale_Price"
        Me.SalePriceDataGridViewTextBoxColumn1.Name = "SalePriceDataGridViewTextBoxColumn1"
        '
        'BindingSource3
        '
        Me.BindingSource3.DataMember = "Refund_Line"
        Me.BindingSource3.DataSource = Me.Group7DataSet1
        '
        'Sale_LineTableAdapter1
        '
        Me.Sale_LineTableAdapter1.ClearBeforeFill = True
        '
        'Sale_LineTableAdapter2
        '
        Me.Sale_LineTableAdapter2.ClearBeforeFill = True
        '
        'BindingSource2
        '
        Me.BindingSource2.DataMember = "Products"
        Me.BindingSource2.DataSource = Me.Group7DataSet2
        '
        'ProductsTableAdapter
        '
        Me.ProductsTableAdapter.ClearBeforeFill = True
        '
        'Sale_Line1TableAdapter1
        '
        Me.Sale_Line1TableAdapter1.ClearBeforeFill = True
        '
        'Product_SaleTableAdapter1
        '
        Me.Product_SaleTableAdapter1.ClearBeforeFill = True
        '
        'Product_RefundTableAdapter1
        '
        Me.Product_RefundTableAdapter1.ClearBeforeFill = True
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Transparent
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button1.Font = New System.Drawing.Font("Segoe UI", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(448, 668)
        Me.Button1.Margin = New System.Windows.Forms.Padding(2)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(157, 42)
        Me.Button1.TabIndex = 88
        Me.Button1.Text = "Back"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Refund_LineTableAdapter1
        '
        Me.Refund_LineTableAdapter1.ClearBeforeFill = True
        '
        'Refunds
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(646, 715)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Sale)
        Me.Controls.Add(Me.txtTotRefund)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btnRefundProducts)
        Me.Controls.Add(Me.txtSaleID)
        Me.Controls.Add(Me.Label2)
        Me.Font = New System.Drawing.Font("Segoe UI", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Name = "Refunds"
        Me.Text = "Refunds"
        CType(Me.SaleLineBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Group7DataSet2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Saleline1Grid, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Group7DataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Sale.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BindingSource3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BindingSource2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtSaleID As System.Windows.Forms.TextBox
    Friend WithEvents Saleline1Grid As System.Windows.Forms.DataGridView
    Friend WithEvents btnRefundProducts As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtTotRefund As System.Windows.Forms.TextBox
    Friend WithEvents Sale As GroupBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Sale_LineTableAdapter1 As group7DataSetTableAdapters.Sale_LineTableAdapter
    Friend WithEvents Group7DataSet1 As group7DataSet
    Friend WithEvents BindingSource1 As BindingSource
    Friend WithEvents LineItemIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ProductIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents SaleIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents UnitQuantityDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents SalePriceDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents Sale_LineTableAdapter2 As group7DataSetTableAdapters.Sale_LineTableAdapter
    Friend WithEvents SaleLineBindingSource As BindingSource
    Friend WithEvents Group7DataSet2 As group7DataSet
    Friend WithEvents BindingSource2 As BindingSource
    Friend WithEvents ProductsTableAdapter As group7DataSetTableAdapters.ProductsTableAdapter
    Friend WithEvents Sale_Line1TableAdapter1 As group7DataSetTableAdapters.Sale_Line1TableAdapter
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents LineItemIDDataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents ProductIDDataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents SaleIDDataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents UnitQuantityDataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents SalePriceDataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents Product_SaleTableAdapter1 As group7DataSetTableAdapters.Product_SaleTableAdapter
    Friend WithEvents Product_RefundTableAdapter1 As group7DataSetTableAdapters.Product_RefundTableAdapter
    Friend WithEvents Button1 As Button
    Friend WithEvents BindingSource3 As BindingSource
    Friend WithEvents Refund_LineTableAdapter1 As group7DataSetTableAdapters.Refund_LineTableAdapter
End Class
